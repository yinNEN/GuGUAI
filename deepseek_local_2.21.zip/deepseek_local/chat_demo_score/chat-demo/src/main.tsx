import { createRoot } from 'react-dom/client'
import { App } from './app/App.js'
import { setupTheme } from './app/theme.js'
import { ensureKatex } from './services/markdown/katex.js'
import { initServerSession } from './services/serverSession.js'
import './app/theme.css'
import './app/global.css'

ensureKatex()
setupTheme()
// 私有化部署：读取当前登录用户；未登录时跳转后端登录页
void initServerSession()

createRoot(document.getElementById('root') as HTMLElement).render(<App />)
