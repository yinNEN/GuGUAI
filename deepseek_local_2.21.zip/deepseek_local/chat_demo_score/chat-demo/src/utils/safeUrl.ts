/** 只允许外部链接使用 http/https，阻断 javascript:、data: 等可执行协议。 */
export const safeExternalUrl = (value: string | null | undefined): string | undefined => {
  if (!value) return undefined
  let candidate = value.trim()
  if (!/^[a-z][a-z0-9+.-]*:/i.test(candidate)) {
    candidate = `https://${candidate}`
  }
  try {
    const parsed = new URL(candidate)
    return parsed.protocol === 'http:' || parsed.protocol === 'https:' ? parsed.toString() : undefined
  } catch {
    return undefined
  }
}
