import { create } from 'zustand'

export type CodePreviewRequest = {
  code: string
  language: string
}

type CodePreviewState = { request: CodePreviewRequest | null }

export const useCodePreview = create<CodePreviewState>(() => ({ request: null }))

export const openCodePreview = (request: CodePreviewRequest) =>
  useCodePreview.setState({ request })

export const closeCodePreview = () => useCodePreview.setState({ request: null })
