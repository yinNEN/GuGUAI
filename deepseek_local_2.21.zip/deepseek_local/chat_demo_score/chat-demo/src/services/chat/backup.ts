import { formatDate } from '../../utils/format.js'
import * as db from './db.js'
import * as sync from './sync.js'
import { replaceHistory, useChatStore } from './store.js'
import { hasUnsyncedFile, mergeServerFileIds } from './fileRefs.js'
import type { Session } from './types.js'

export { BackupError } from './history/errors.js'

// 导入、导出与全部删除串行处理，避免读取归档时数据被清空或两个替换事务交错。
let backupQueue: Promise<unknown> = Promise.resolve()

const enqueueBackup = <T>(run: () => Promise<T>): Promise<T> => {
  const task = backupQueue.then(run)
  backupQueue = task.catch(() => {})
  return task
}

const backupFileName = (date: Date) => `deepseek_data-${formatDate(date)}.zip`

/** 导出为历史会话导出格式的 ZIP，可再次导入。 */
export const exportHistory = (compatible = false): Promise<{ name: string; blob: Blob }> =>
  enqueueBackup(async () => {
    // 列表和已加载内容保留导出开始时的快照；未打开的会话逐条读取，不填满详情缓存。
    const { sessions, sessionCache } = useChatStore.getState()
    async function* readSessions(): AsyncGenerator<Session> {
      for (const summary of sessions) {
        let session = Object.hasOwn(sessionCache, summary.id)
          ? sessionCache[summary.id]
          : await db.loadSession(summary.id)
        // 服务端摘要可能已缓存、详情尚未下载（例如从未在当前设备打开）。
        // 导出前按需回源，避免把“摘要存在但详情未缓存”误判成会话消失。
        if (!session) {
          session = (await sync.getRemoteSession(summary.id)) ?? undefined
          if (session) {
            await db.saveSession(session).catch(() => {})
          }
        } else if (session && __SERVER_MANAGED__ && hasUnsyncedFile(session)) {
          // Older local details can predate the server IDs written by an
          // import on another device. Merge only file IDs, not message content.
          const remote = await sync.getRemoteSession(summary.id).catch(() => null)
          if (remote) {
            session = mergeServerFileIds(session, remote)
            await db.saveSession(session).catch(() => {})
          }
        }
        if (!session) {
          // 另一台设备已删除该会话时不再阻塞整个归档。
          console.warn('[backup] skip missing session', summary.id)
          continue
        }
        // 详情读取期间可能重命名，归档标题与开始时的列表保持一致。
        yield { ...session, ...summary }
      }
    }
    const { exportArchive } = await import('./history/exportArchive.js')
    const now = new Date()
    const blob = await exportArchive(readSessions(), { compatible })
    return { name: backupFileName(now), blob }
  })

/**
 * 确认覆盖后调用：先检查 ZIP 格式与版本，校验失败时保留正在生成的回答；
 * 通过后从 ZIP 流式写入暂存，成功才替换原有会话与图片原件。返回导入的会话数。
 */
export const importHistory = (file: File): Promise<number> =>
  enqueueBackup(async () => {
    const { checkArchiveFormat, importArchive } = await import('./history/importArchive.js')
    await checkArchiveFormat(file)
    return replaceHistory(() => importArchive(file))
  })

/** 确认删除后调用：以空历史原子替换全部本地会话与附件，保留 API Key 和其他设置。 */
export const clearHistory = (): Promise<void> =>
  enqueueBackup(async () => {
    await replaceHistory(async () => {})
  })
