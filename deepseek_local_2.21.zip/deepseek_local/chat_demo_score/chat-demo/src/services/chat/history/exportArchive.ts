import * as db from '../db.js'
import type { Session } from '../types.js'
import { EXPORT_FORMAT_VERSION, type Manifest, type SessionIndexEntry } from './format.js'
import { INDEX_PATH, MANIFEST_PATH, imagePath, sessionPath } from './paths.js'
import { toIndexEntry, toSessionFile } from './toArchive.js'
import { writeArchive } from './zipWriter.js'

const json = (value: unknown) => new Blob([JSON.stringify(value)], { type: 'application/json' })

/**
 * 按导出格式生成 ZIP：manifest → 全部会话 JSON → index → 全部本地原件。没有账号信息，不写 user.json。
 * 写出本地存在的全部附件原件（图片、文本、代码等），每个会话目录各写一份；没有原件的附件只有元数据。
 */
export const exportArchive = async (
  sessions: Iterable<Session> | AsyncIterable<Session>,
  options: { compatible?: boolean } = {}
): Promise<Blob> => {
  // 兼容模式只写图片原件，生成的 ZIP 与 DeepSeek 官方客户端/最初网页导出的格式一致。
  const includeAllFiles = options.compatible !== true
  const manifest: Manifest = { export_format_version: EXPORT_FORMAT_VERSION }
  const entries = [{ name: MANIFEST_PATH, blob: json(manifest) }]
  const imageEntries: { name: string; blob: Blob }[] = []
  const index: SessionIndexEntry[] = []
  const originals = new Map<string, Blob | undefined>()
  const loadOriginal = async (file: { id: string; serverId?: string | null }) => {
    const local = await db.loadFile(file.id)
    if (local) {
      return local
    }
    // 另一台设备可能只有附件元数据；导出时按 serverId 从服务器补拉原件。
    // Prefer the server copy whenever an attachment has a server ID. This
    // also covers deployments where the frontend is not in server-managed
    // mode but the file endpoint is still available.
    if (file.serverId) {
      try {
        const response = await fetch(`/api/files/${encodeURIComponent(file.serverId)}`, {
          credentials: 'same-origin',
        })
        if (response.ok) {
          return await response.blob()
        }
      } catch {
        // 服务器文件已清理时只导出元数据，不阻塞整个归档。
      }
    }
    return undefined
  }
  for await (const session of sessions) {
    for (const message of session.messages) {
      if (message.role === 'user') {
        for (const file of message.files) {
          if ((includeAllFiles || file.isImage) && !originals.has(file.id)) {
            originals.set(file.id, await loadOriginal(file))
          }
        }
      }
    }
    const images = new Map<string, Blob>()
    const data = toSessionFile(session, ({ id, name, isImage }) => {
      const blob = originals.get(id)
      if (!blob || (!includeAllFiles && !isImage)) {
        return null
      }
      const path = imagePath(session.id, id, name)
      images.set(path, blob)
      return path
    })
    entries.push({ name: sessionPath(session.id), blob: json(data) })
    for (const [name, blob] of images) {
      imageEntries.push({ name, blob })
    }
    index.push(toIndexEntry(data))
  }
  entries.push({ name: INDEX_PATH, blob: json(index) })
  return writeArchive(entries.concat(imageEntries))
}
