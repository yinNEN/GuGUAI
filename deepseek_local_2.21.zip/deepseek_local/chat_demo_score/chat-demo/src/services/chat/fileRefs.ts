import type { Session } from './types.js'

/** 本地详情里仍有附件没拿到服务端 ID（例如导入完成后另一台设备的旧缓存）。 */
export const hasUnsyncedFile = (session: Session): boolean =>
  session.messages.some(
    (message) => message.role === 'user' && message.files.some((file) => !file.serverId)
  )

/**
 * 只合并服务端详情的附件 ID，不覆盖本地消息内容。
 * 导入后原文件先上传到服务器，再把新 serverId 写进会话快照；另一台设备
 * 可能仍持有导入前的旧详情，此时必须补上 ID 才能读取漫游文件。
 */
export const mergeServerFileIds = (local: Session, remote: Session): Session => {
  const remoteIds = new Map<string, string>()
  for (const message of remote.messages) {
    if (message.role !== 'user') {
      continue
    }
    for (const file of message.files) {
      if (file.serverId) {
        remoteIds.set(file.id, file.serverId)
      }
    }
  }
  if (remoteIds.size === 0) {
    return local
  }
  let changed = false
  const messages = local.messages.map((message) => {
    if (message.role !== 'user') {
      return message
    }
    let filesChanged = false
    const files = message.files.map((file) => {
      const serverId = !file.serverId ? remoteIds.get(file.id) : undefined
      if (!serverId) {
        return file
      }
      filesChanged = true
      return { ...file, serverId }
    })
    if (!filesChanged) {
      return message
    }
    changed = true
    return { ...message, files }
  })
  return changed ? { ...local, messages } : local
}
