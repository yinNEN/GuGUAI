import type { Session, SessionSummary } from '../chat/types.js'
import * as db from '../chat/db.js'
import { redirectToLogin, reloadForUserChange, sessionUserHeaders } from '../serverSession.js'
import { uploadImportedFiles } from './importFiles.js'

/**
 * 服务端会话同步：
 * - 启动时把本地摘要与服务端摘要合并，服务端较新的会话以服务端为准；
 * - 本地修改（发送、改名、删除、导入）异步推送到 /api/sync/sessions；
 * - 消息本身仍由后端代理在调用 DeepSeek 前落库，这里同步的是完整会话结构（含分支/附件元数据）。
 */

const DEBOUNCE_MS = 800
const RETRY_MS = 3000
/** 历史导入/删除全部完成后，服务端替换失败时置位，下次启动重试 */
export const REPLACE_PENDING_KEY = 'chat-demo:sync-replace-pending'

const pending = new Map<string, Session>()
const timers = new Map<string, ReturnType<typeof setTimeout>>()
const chains = new Map<string, Promise<void>>()
const retryCount = new Map<string, number>()

const clearTimer = (id: string) => {
  const timer = timers.get(id)
  if (timer !== undefined) {
    clearTimeout(timer)
    timers.delete(id)
  }
}

const throwForStatus = async (response: Response): Promise<never> => {
  let detail = `同步失败（HTTP ${response.status}）`
  try {
    const body: unknown = await response.json()
    if (body && typeof body === 'object' && typeof (body as { detail?: unknown }).detail === 'string') {
      detail = (body as { detail: string }).detail
    }
  } catch {
    // 非 JSON 错误响应
  }
  throw new Error(detail)
}

const request = async (path: string, init: RequestInit = {}): Promise<Response> => {
  let response: Response
  try {
    response = await fetch(path, {
      credentials: 'same-origin',
      ...init,
      headers: { Accept: 'application/json', ...sessionUserHeaders(), ...(init.headers ?? {}) },
    })
  } catch (error) {
    throw new Error(`网络异常：${error instanceof Error ? error.message : String(error)}`)
  }
  if (response.status === 401 && response.headers.get('X-Session-Expired') === '1') {
    redirectToLogin()
  }
  if (response.status === 409 && response.headers.get('X-Session-User-Changed') === '1') {
    reloadForUserChange()
  }
  return response
}

export const listRemoteSessions = async (): Promise<SessionSummary[]> => {
  if (!__SERVER_MANAGED__) {
    return []
  }
  const response = await request('/api/sync/sessions', { signal: AbortSignal.timeout(8000) })
  if (!response.ok) {
    await throwForStatus(response)
  }
  const body = (await response.json()) as { sessions?: SessionSummary[] }
  return Array.isArray(body.sessions) ? body.sessions : []
}

export const getRemoteSession = async (id: string): Promise<Session | null> => {
  if (!__SERVER_MANAGED__) {
    return null
  }
  const response = await request(`/api/sync/sessions/${encodeURIComponent(id)}`)
  if (response.status === 404) {
    return null
  }
  if (!response.ok) {
    await throwForStatus(response)
  }
  const body = (await response.json()) as { session?: Session }
  return body.session ?? null
}

const enqueue = (id: string, task: () => Promise<void>): Promise<void> => {
  const previous = chains.get(id) ?? Promise.resolve()
  const next = previous.catch(() => {}).then(task)
  chains.set(id, next)
  void next
    .catch(() => {})
    .finally(() => {
      if (chains.get(id) === next) {
        chains.delete(id)
      }
    })
  return next
}

export const pushSession = (session: Session, keepalive = false): Promise<void> =>
  enqueue(session.id, async () => {
    const response = await request(`/api/sync/sessions/${encodeURIComponent(session.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(session),
      keepalive,
    })
    if (!response.ok) {
      await throwForStatus(response)
    }
    db.clearSessionLocalNew(session.id)
    retryCount.delete(session.id)
  })

const settleChain = async (id: string): Promise<void> => {
  const chain = chains.get(id)
  if (chain) {
    await chain.catch(() => {})
  }
}

export const deleteRemoteSession = async (id: string): Promise<void> => {
  if (!__SERVER_MANAGED__) {
    return
  }
  clearTimer(id)
  pending.delete(id)
  // 等本会话在途的推送完成，避免 DELETE 之后又被 PUT 写回来
  await settleChain(id)
  const response = await request(`/api/sync/sessions/${encodeURIComponent(id)}`, { method: 'DELETE' })
  if (!response.ok && response.status !== 404) {
    await throwForStatus(response)
  }
}

export const renameRemoteSession = async (id: string, title: string): Promise<void> => {
  if (!__SERVER_MANAGED__) {
    return
  }
  const response = await request(`/api/sync/sessions/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title }),
  })
  // 本地尚未推送过的新会话可能还没有服务端记录，等后续快照推送即可
  if (!response.ok && response.status !== 404) {
    await throwForStatus(response)
  }
}

const dropPending = (): void => {
  for (const id of [...timers.keys()]) {
    clearTimer(id)
  }
  pending.clear()
}

export const replaceRemoteSessions = async (sessions: Session[]): Promise<void> => {
  if (!__SERVER_MANAGED__) {
    return
  }
  // 整体替换前清空待推送队列并等待在途请求，避免旧会话被重新写回
  dropPending()
  await Promise.all([...chains.values()].map((chain) => chain.catch(() => {})))
  dropPending()
  const response = await request('/api/sync/sessions/replace', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessions }),
  })
  if (!response.ok) {
    await throwForStatus(response)
  }
}

const flush = (id: string, keepalive = false): Promise<void> => {
  clearTimer(id)
  const session = pending.get(id)
  if (!session) {
    return Promise.resolve()
  }
  pending.delete(id)
  return pushSession(session, keepalive)
    .catch((error: unknown) => {
      console.warn('[sync] push session failed', error)
      const attempt = (retryCount.get(id) ?? 0) + 1
      retryCount.set(id, attempt)
      // 保留最新内容，指数退避重试；页面关闭时由 flushAll 尽力发送
      pending.set(id, session)
      if (attempt <= 5) {
        timers.set(
          id,
          setTimeout(() => void flush(id), RETRY_MS * Math.min(attempt, 4))
        )
      }
    })
}

/** 本地保存成功后调用；短时间内的连续更新合并为一次推送 */
export const schedulePush = (session: Session, delay = DEBOUNCE_MS): void => {
  if (!__SERVER_MANAGED__) {
    return
  }
  pending.set(session.id, session)
  clearTimer(session.id)
  timers.set(
    session.id,
    setTimeout(() => void flush(session.id), delay)
  )
}

/** 发送请求前确保服务器已有本轮消息；失败不阻断对话，后续会重试 */
export const pushNow = async (session: Session): Promise<void> => {
  if (!__SERVER_MANAGED__) {
    return
  }
  pending.delete(session.id)
  clearTimer(session.id)
  try {
    // 不让同步阻塞聊天：5 秒内没推上去就先发送，后台继续重试
    await Promise.race([
      pushSession(session),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('sync timeout')), 5000)
      ),
    ])
  } catch (error) {
    console.warn('[sync] push before send failed', error)
    pending.set(session.id, session)
    clearTimer(session.id)
    timers.set(
      session.id,
      setTimeout(() => void flush(session.id), RETRY_MS)
    )
  }
}

/** 删除本地会话后清掉可能残留的推送任务 */
export const cancelSession = (id: string): void => {
  clearTimer(id)
  pending.delete(id)
  retryCount.delete(id)
}

/** 页面隐藏/关闭前尽力推送 */
export const flushAll = async (): Promise<void> => {
  const ids = [...pending.keys()]
  for (const id of ids) {
    clearTimer(id)
  }
  await Promise.all(ids.map((id) => flush(id, true)))
}

/** 历史导入或删除全部后，重试上次未完成的服务端替换 */
const retryPendingReplace = async (): Promise<void> => {
  if (localStorage.getItem(REPLACE_PENDING_KEY) !== '1') {
    return
  }
  const sessions = await db.loadAllSessions()
  const imported = await uploadImportedFiles(sessions)
  await replaceRemoteSessions(imported.sessions)
  localStorage.removeItem(REPLACE_PENDING_KEY)
}

/**
 * 启动同步：返回合并后的摘要列表。
 * 服务端较新时丢弃本地详情，改为按需从服务端拉取；本地较新时排队推送。
 */
export const syncOnInit = async (local: SessionSummary[]): Promise<SessionSummary[]> => {
  if (!__SERVER_MANAGED__) {
    return local
  }
  try {
    await retryPendingReplace()
  } catch (error) {
    console.warn('[sync] pending replace failed', error)
  }
  // 替换尚未成功时服务端列表并不可信，必须保留本地导入结果，等待下次重试
  if (localStorage.getItem(REPLACE_PENDING_KEY) === '1') {
    return local
  }

  let remote: SessionSummary[]
  try {
    remote = await listRemoteSessions()
  } catch (error) {
    console.warn('[sync] list sessions failed, using local cache', error)
    return local
  }

  const localMap = new Map(local.map((session) => [session.id, session]))
  const remoteMap = new Map(remote.map((session) => [session.id, session]))
  const merged = new Map<string, SessionSummary>()
  const toPush: string[] = []

  for (const summary of local) {
    const server = remoteMap.get(summary.id)
    if (!server) {
      // 服务端列表成功返回但不含该会话：若不是本机新建待推送，说明已在其他设备删除。
      if (!db.isSessionLocalNew(summary.id)) {
        try {
          await db.deleteSession(summary.id)
        } catch (error) {
          console.warn('[sync] remove remotely deleted session failed', error)
        }
        continue
      }
      merged.set(summary.id, summary)
      toPush.push(summary.id)
      continue
    }
    if (server.updatedAt > summary.updatedAt) {
      try {
        // 服务端更新：删掉本地旧详情，保留摘要，打开时从服务端加载
        await db.deleteSession(summary.id)
        await db.saveSessionSummary(server)
      } catch (error) {
        console.warn('[sync] replace local summary failed', error)
      }
      merged.set(summary.id, server)
    } else {
      merged.set(summary.id, summary)
      if (summary.updatedAt > server.updatedAt) {
        toPush.push(summary.id)
      }
    }
  }

  for (const summary of remote) {
    db.clearSessionLocalNew(summary.id)
    if (localMap.has(summary.id)) {
      continue
    }
    try {
      await db.saveSessionSummary(summary)
      merged.set(summary.id, summary)
    } catch (error) {
      console.warn('[sync] cache remote summary failed', error)
    }
  }

  for (const id of toPush) {
    try {
      const session = await db.loadSession(id)
      if (session) {
        schedulePush(session, 0)
      }
    } catch (error) {
      console.warn('[sync] queue local session failed', error)
    }
  }

  return [...merged.values()].sort((a, b) => b.updatedAt - a.updatedAt)
}
