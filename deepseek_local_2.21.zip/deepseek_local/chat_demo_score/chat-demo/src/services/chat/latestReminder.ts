import type { Locale } from '../settings.js'
import { formatDate } from '../../utils/format.js'
import { translate } from '../../i18n/index.js'


/** 模型约定的五项信息；日期与星期使用浏览器本地时区，避免 UTC 日期跨日。 */
export const createLatestReminder = (
  { locale }: { locale: Locale },
  now = new Date()
): string => {
  return [
    formatDate(now),
    new Intl.DateTimeFormat(locale, { weekday: 'long' }).format(now),
    // 位置设置已移除，但上游 latest_reminder 仍要求五项；保留空位置字段，
    // 避免把四段字符串发给真实 DeepSeek 接口导致请求被拒绝。
    '',
    'Web',
    translate('latestReminderLanguage'),
  ].join(',')
}
