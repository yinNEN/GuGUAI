import { create } from 'zustand'

export type FilePreviewRequest = {
  name: string
  /** 草稿里的 File，优先读取 */
  file?: File
  /** IndexedDB 原件 ID */
  localId?: string
  /** 服务端缓冲区文件 ID */
  serverId?: string | null
  /** 浏览器给出的 MIME，图片预览时优先使用 */
  mimeType?: string
}

type FilePreviewState = {
  request: FilePreviewRequest | null
}

export const useFilePreview = create<FilePreviewState>(() => ({ request: null }))

export const openFilePreview = (request: FilePreviewRequest) => useFilePreview.setState({ request })

export const closeFilePreview = () => useFilePreview.setState({ request: null })
