import { useCallback, useEffect, useRef, useState } from 'react'
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.js'
import { useTranslate } from '../../i18n/index.js'
import styles from './FilePreview.module.css'

/** Keep the DOM/canvas workload bounded for very large PDFs. */
const MAX_PAGES = 50
const MIN_PAGE_WIDTH = 240
const MAX_PAGE_WIDTH = 1400

type ZoomMode = 'fit' | '0.5' | '0.75' | '1' | '1.25' | '1.5' | '2'
type ViewMode = 'continuous' | 'single'

pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  'static/pdf.worker.min.js',
  typeof document === 'undefined' ? 'http://localhost/' : document.baseURI
).toString()

const asPage = (value: number, count: number) =>
  Math.max(1, Math.min(Number.isFinite(value) ? Math.round(value) : 1, count))

/** Render PDF pages into canvases with pdf.js. No PDF content is inserted as HTML. */
export const PdfViewer = ({
  url,
  onError,
  onLimited,
}: {
  url: string
  onError: () => void
  onLimited: (limited: boolean) => void
}) => {
  const t = useTranslate()
  const scrollRef = useRef<HTMLDivElement>(null)
  const canvasHostRef = useRef<HTMLDivElement>(null)
  const pageRefs = useRef(new Map<number, HTMLDivElement>())
  const pageText = useRef<string[]>([])
  const navigatingRef = useRef(false)
  const [loading, setLoading] = useState(true)
  const [pageCount, setPageCount] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [zoom, setZoom] = useState<ZoomMode>('fit')
  const [viewMode, setViewMode] = useState<ViewMode>('continuous')
  const [lightDocument, setLightDocument] = useState(false)
  const [query, setQuery] = useState('')
  const [searchStatus, setSearchStatus] = useState('')

  useEffect(() => {
    let cancelled = false
    let document: pdfjs.PDFDocumentProxy | undefined
    const tasks: pdfjs.RenderTask[] = []
    const run = async () => {
      setLoading(true)
      setSearchStatus('')
      try {
        document = await pdfjs.getDocument({ url, isEvalSupported: false }).promise
        const host = canvasHostRef.current
        const scroll = scrollRef.current
        if (!host || !scroll || cancelled) return

        setPageCount(document.numPages)
        setCurrentPage((value) => asPage(value, document!.numPages))
        onLimited(document.numPages > MAX_PAGES)
        host.replaceChildren()
        pageRefs.current.clear()
        pageText.current = []

        const available = Math.max(
          MIN_PAGE_WIDTH,
          (scroll.clientWidth || 900) - 48
        )
        const zoomScale = zoom === 'fit' ? 1 : Number(zoom)
        const outputScale = Math.min(window.devicePixelRatio || 1, 2)
        const count = Math.min(document.numPages, MAX_PAGES)

        for (let pageNumber = 1; pageNumber <= count; pageNumber += 1) {
          if (cancelled) return
          const page = await document.getPage(pageNumber)
          const base = page.getViewport({ scale: 1 })
          const cssScale = Math.max(
            MIN_PAGE_WIDTH / base.width,
            Math.min((available * zoomScale) / base.width, MAX_PAGE_WIDTH / base.width)
          )
          const cssViewport = page.getViewport({ scale: cssScale })
          const renderViewport = page.getViewport({ scale: cssScale * outputScale })

          const wrapper = window.document.createElement('div')
          wrapper.className = styles.pdfPageWrap
          wrapper.dataset.page = String(pageNumber)
          const canvas = window.document.createElement('canvas')
          canvas.className = styles.pdfPage
          canvas.width = Math.floor(renderViewport.width)
          canvas.height = Math.floor(renderViewport.height)
          canvas.style.width = `${cssViewport.width}px`
          canvas.style.height = `${cssViewport.height}px`
          canvas.setAttribute('aria-label', `PDF page ${pageNumber}`)
          wrapper.appendChild(canvas)
          host.appendChild(wrapper)
          pageRefs.current.set(pageNumber, wrapper)
          wrapper.style.setProperty('--scale-factor', String(cssScale))

          const context = canvas.getContext('2d')
          if (!context) throw new Error('no 2d context')
          const task = page.render({ canvasContext: context, viewport: renderViewport })
          tasks.push(task)
          await task.promise

          try {
            const content = await page.getTextContent()
            pageText.current[pageNumber - 1] = content.items
              .map((item) => ('str' in item ? item.str : ''))
              .join(' ')
            // Transparent real text over the canvas: enables selection/copy while
            // keeping PDF.js output out of application HTML.
            const textDiv = window.document.createElement('div')
            textDiv.className = styles.pdfTextLayer
            wrapper.appendChild(textDiv)
            const textTask = pdfjs.renderTextLayer({
              textContentSource: content,
              container: textDiv,
              viewport: cssViewport,
            })
            await textTask.promise
          } catch {
            pageText.current[pageNumber - 1] = ''
          }
        }
      } catch {
        if (!cancelled) onError()
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    void run()
    return () => {
      cancelled = true
      for (const task of tasks) task.cancel()
      void document?.destroy()
      pageRefs.current.clear()
      pageText.current = []
      canvasHostRef.current?.replaceChildren()
    }
  }, [url, zoom, onError, onLimited])

  useEffect(() => {
    for (const [page, node] of pageRefs.current) {
      node.style.display = viewMode === 'single' && page !== currentPage ? 'none' : ''
    }
  }, [currentPage, pageCount, viewMode])

  const scrollToPage = useCallback((page: number) => {
    if (pageCount === 0) return
    const next = asPage(page, pageCount)
    setCurrentPage(next)
    if (viewMode === 'single') return
    navigatingRef.current = true
    pageRefs.current.get(next)?.scrollIntoView({ block: 'start', behavior: 'auto' })
    window.setTimeout(() => {
      navigatingRef.current = false
    }, 300)
  }, [pageCount, viewMode])

  const onScroll = useCallback(() => {
    if (viewMode !== 'continuous' || !scrollRef.current || navigatingRef.current) return
    const top = scrollRef.current.getBoundingClientRect().top
    let visible = 1
    for (const [page, node] of pageRefs.current) {
      if (node.getBoundingClientRect().top <= top + 32) visible = page
    }
    if (visible !== currentPage) setCurrentPage(visible)
  }, [currentPage, viewMode])

  const find = useCallback(
    (direction: 1 | -1) => {
      const term = query.trim().toLocaleLowerCase()
      if (!term || pageCount === 0) return
      for (let offset = 1; offset <= pageCount; offset += 1) {
        const page = ((currentPage - 1 + direction * offset + pageCount) % pageCount) + 1
        if ((pageText.current[page - 1] || '').toLocaleLowerCase().includes(term)) {
          setSearchStatus(`${page}/${pageCount}`)
          scrollToPage(page)
          return
        }
      }
      setSearchStatus(t('pdfNoMatches'))
    },
    [currentPage, pageCount, query, scrollToPage, t]
  )

  const zoomBy = (direction: 1 | -1) => {
    const steps = [0.5, 0.75, 1, 1.25, 1.5, 2]
    const current = zoom === 'fit' ? 1 : Number(zoom)
    const index = steps.findIndex((step) => Math.abs(step - current) < 0.01)
    const next = steps[Math.max(0, Math.min(steps.length - 1, (index < 0 ? 2 : index) + direction))]
    setZoom(String(next) as ZoomMode)
  }

  return (
    <div className={`${styles.pdfViewer}${lightDocument ? ` ${styles.pdfLight}` : ''}`}>
      <div className={styles.pdfToolbar}>
        <div className={styles.pdfGroup}>
          <button type="button" className={styles.pdfButton} aria-label={t('pdfPreviousPage')} onClick={() => scrollToPage(currentPage - 1)}>
            ‹
          </button>
          <input
            className={styles.pdfPageInput}
            aria-label={t('pdfPage')}
            type="number"
            min={1}
            max={pageCount || 1}
            value={currentPage}
            onChange={(event) => scrollToPage(Number(event.target.value))}
          />
          <span className={styles.pdfCount}>{pageCount ? `${currentPage} / ${pageCount}` : '-'}</span>
          <button type="button" className={styles.pdfButton} aria-label={t('pdfNextPage')} onClick={() => scrollToPage(currentPage + 1)}>
            ›
          </button>
        </div>
        <div className={styles.pdfGroup}>
          <input
            className={styles.pdfSearch}
            aria-label={t('pdfFind')}
            placeholder={t('pdfFind')}
            value={query}
            onChange={(event) => {
              setQuery(event.target.value)
              setSearchStatus('')
            }}
            onKeyDown={(event) => {
              if (event.key === 'Enter') find(event.shiftKey ? -1 : 1)
            }}
          />
          <button type="button" className={styles.pdfButton} aria-label={t('pdfFindPrevious')} onClick={() => find(-1)}>
            ↑
          </button>
          <button type="button" className={styles.pdfButton} aria-label={t('pdfFindNext')} onClick={() => find(1)}>
            ↓
          </button>
          {searchStatus ? <span className={styles.pdfSearchStatus}>{searchStatus}</span> : null}
        </div>
        <div className={styles.pdfGroup}>
          <button type="button" className={styles.pdfButton} aria-label={t('pdfZoomOut')} onClick={() => zoomBy(-1)}>
            −
          </button>
          <select
            className={styles.pdfSelect}
            aria-label={t('pdfZoom')}
            value={zoom}
            onChange={(event) => setZoom(event.target.value as ZoomMode)}
          >
            <option value="fit">{t('pdfFitWidth')}</option>
            <option value="0.5">50%</option>
            <option value="0.75">75%</option>
            <option value="1">100%</option>
            <option value="1.25">125%</option>
            <option value="1.5">150%</option>
            <option value="2">200%</option>
          </select>
          <button type="button" className={styles.pdfButton} aria-label={t('pdfZoomIn')} onClick={() => zoomBy(1)}>
            +
          </button>
          <select
            className={styles.pdfSelect}
            aria-label={t('pdfViewMode')}
            value={viewMode}
            onChange={(event) => setViewMode(event.target.value as ViewMode)}
          >
            <option value="continuous">{t('pdfContinuous')}</option>
            <option value="single">{t('pdfSingle')}</option>
          </select>
          <label className={styles.pdfToggle}>
            <input
              type="checkbox"
              checked={lightDocument}
              onChange={(event) => setLightDocument(event.target.checked)}
            />
            {t('pdfKeepLight')}
          </label>
        </div>
      </div>
      <div className={styles.pdfPages} ref={scrollRef} aria-busy={loading} onScroll={onScroll}>
        {loading ? <div className={styles.status}>{t('filePreviewLoading')}</div> : null}
        <div className={styles.pdfCanvasHost} ref={canvasHostRef} />
      </div>
    </div>
  )
}
