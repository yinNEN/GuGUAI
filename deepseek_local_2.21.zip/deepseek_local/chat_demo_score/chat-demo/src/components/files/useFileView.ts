import { useEffect, useState } from 'react'
import { getFileViewType, isImage } from '../../services/attachments.js'
import { loadFile } from '../../services/chat/db.js'

const createViewUrl = (original: Blob, type: string) => {
  const blob = original.slice(0, original.size, type || 'application/octet-stream')
  if (!isImage(type)) {
    return URL.createObjectURL(blob)
  }
  // 所有图片缩略图都用 data: 地址，不依赖部分浏览器可能异常的 blob URL。
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(blob)
  })
}

const loadRemoteFile = async (serverId: string): Promise<Blob | null> => {
  try {
    const response = await fetch(`/api/files/${encodeURIComponent(serverId)}`, {
      credentials: 'same-origin',
    })
    return response.ok ? await response.blob() : null
  } catch {
    return null
  }
}

/** 草稿传 File，已发送的附件传 IndexedDB 原件 ID；本地没有原件时回退到服务端缓冲区。 */
export const useFileView = (source: File | string, name: string, serverId?: string | null) => {
  const type = getFileViewType(name)
  const [state, setState] = useState<{ source: File | string; type: string; url: string | null }>()
  useEffect(() => {
    let active = true
    const original =
      typeof source === 'string'
        ? loadFile(source).then((blob) => {
            if (blob) {
              return blob
            }
            return serverId ? loadRemoteFile(serverId) : null
          })
        : Promise.resolve(source)
    const pending = original
      .then((blob) => (active && blob ? createViewUrl(blob, type) : null))
      .catch(() => null)
    void pending.then((url) => {
      if (active) {
        setState({ source, type, url })
      }
    })
    return () => {
      active = false
      void pending.then((url) => {
        if (url?.startsWith('blob:')) {
          URL.revokeObjectURL(url)
        }
      })
    }
  }, [source, type, serverId])

  const url = state?.source === source && state.type === type ? state.url : undefined
  const image = isImage(type)
  const openInTab = type === 'application/pdf' || (image && type !== 'image/svg+xml')
  const action = openInTab ? { target: '_blank', rel: 'noreferrer' } : { download: name }
  return { url, image, link: url ? { href: url, ...action } : undefined }
}
