import { useCallback, useEffect, useRef, useState } from 'react'
import { getFileViewType, isImage } from '../../services/attachments.js'
import { useTranslate } from '../../i18n/index.js'
import { loadFile } from '../../services/chat/db.js'
import {
  closeFilePreview,
  useFilePreview,
  type FilePreviewRequest,
} from '../../services/filePreview.js'
import { Modal } from '../base/Modal.js'
import { PdfViewer } from './PdfViewer.js'
import styles from './FilePreview.module.css'

const readLocal = async (request: FilePreviewRequest): Promise<string | null> => {
  if (request.file) {
    return request.file.text()
  }
  if (request.localId) {
    const blob = await loadFile(request.localId)
    if (blob) {
      return blob.text()
    }
  }
  return null
}

const blobToDataUrl = (blob: Blob) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result))
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(blob)
  })

const loadBinaryBlob = async (request: FilePreviewRequest): Promise<Blob | null> => {
  if (request.file) {
    return request.file
  }
  if (request.localId) {
    const local = await loadFile(request.localId)
    if (local) {
      return local
    }
  }
  if (request.serverId) {
    const response = await fetch(`/api/files/${encodeURIComponent(request.serverId)}`, {
      credentials: 'same-origin',
    })
    if (response.ok) {
      const blob = await response.blob()
      const type = request.mimeType || getFileViewType(request.name)
      // 服务端下载响应可能是 application/octet-stream，用附件 MIME 修正后转 data URL
      return type && blob.type !== type ? new Blob([blob], { type }) : blob
    }
  }
  return null
}

const readServer = async (serverId: string): Promise<{ text: string; truncated: boolean }> => {
  const response = await fetch(`/api/files/${encodeURIComponent(serverId)}/text`, {
    credentials: 'same-origin',
    headers: { Accept: 'application/json' },
  })
  if (response.ok) {
    const body = (await response.json()) as { text?: string; truncated?: boolean }
    return { text: body.text ?? '', truncated: body.truncated === true }
  }
  const fallback = await fetch(`/api/files/${encodeURIComponent(serverId)}`, {
    credentials: 'same-origin',
  })
  if (!fallback.ok) {
    throw new Error(String(response.status))
  }
  return { text: await fallback.text(), truncated: false }
}

/** 文本/代码附件预览：本地原件优先，其次从服务器缓冲区读取 */
export const FilePreview = () => {
  const t = useTranslate()
  const request = useFilePreview((state) => state.request)
  const [text, setText] = useState('')
  const [imageUrl, setImageUrl] = useState('')
  const [pdfUrl, setPdfUrl] = useState('')
  const [pdfMode, setPdfMode] = useState<'pdfjs' | 'native'>('pdfjs')
  const [pdfError, setPdfError] = useState(false)
  const [pdfLimited, setPdfLimited] = useState(false)
  const pdfUrlRef = useRef('')
  const [truncated, setTruncated] = useState(false)
  const [error, setError] = useState(false)
  const [loading, setLoading] = useState(false)
  const [mode, setMode] = useState<'preview' | 'source'>('preview')
  const ext = request?.name.split('.').pop()?.toLowerCase() ?? ''
  const runnable = ext === 'html' || ext === 'htm' || ext === 'svg'
  const viewType = request ? request.mimeType || getFileViewType(request.name) : ''
  const rasterImage = isImage(viewType) && viewType !== 'image/svg+xml'
  const pdf = viewType === 'application/pdf'

  const handlePdfError = useCallback(() => setPdfError(true), [])
  const handlePdfLimited = useCallback((limited: boolean) => setPdfLimited(limited), [])

  useEffect(() => {
    if (!request) {
      return
    }
    let active = true
    setLoading(true)
    setError(false)
    setText('')
    setImageUrl('')
    setPdfUrl('')
    setPdfMode('pdfjs')
    setPdfError(false)
    setPdfLimited(false)
    if (pdfUrlRef.current) {
      URL.revokeObjectURL(pdfUrlRef.current)
      pdfUrlRef.current = ''
    }
    setTruncated(false)
    setMode(request.name.toLowerCase().endsWith('.html') || request.name.toLowerCase().endsWith('.htm') || request.name.toLowerCase().endsWith('.svg') ? 'preview' : 'source')
    const run = async () => {
      try {
        if (rasterImage) {
          const blob = await loadBinaryBlob(request)
          if (!blob) {
            throw new Error('no image')
          }
          const dataUrl = await blobToDataUrl(blob)
          if (active) {
            setImageUrl(dataUrl)
          }
          return
        }
        if (pdf) {
          const blob = await loadBinaryBlob(request)
          if (!blob) {
            throw new Error('no pdf')
          }
          const url = URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }))
          if (!active) {
            URL.revokeObjectURL(url)
            return
          }
          pdfUrlRef.current = url
          setPdfUrl(url)
          return
        }
        const local = await readLocal(request)
        if (local !== null) {
          if (active) {
            setText(local)
          }
          return
        }
        if (request.serverId) {
          const remote = await readServer(request.serverId)
          if (active) {
            setText(remote.text)
            setTruncated(remote.truncated)
          }
          return
        }
        throw new Error('no source')
      } catch {
        if (active) {
          setError(true)
        }
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }
    void run()
    return () => {
      active = false
      if (pdfUrlRef.current) {
        URL.revokeObjectURL(pdfUrlRef.current)
        pdfUrlRef.current = ''
      }
    }
  }, [request, rasterImage, pdf])

  if (!request) {
    return null
  }

  return (
    <Modal
      title={request.name}
      closable
      className={styles.modal}
      mainClassName={styles.main}
      headerExtra={
        pdf ? (
          <>
            <button
              type="button"
              className={styles.headerAction}
              disabled={!pdfUrl}
              onClick={() => {
                setPdfError(false)
                setPdfMode(pdfMode === 'native' ? 'pdfjs' : 'native')
              }}
            >
              {pdfMode === 'native' ? t('pdfJavascriptPreview') : t('pdfNativePreview')}
            </button>
            <button
              type="button"
              className={styles.headerAction}
              disabled={!pdfUrl}
              onClick={() => {
                if (pdfUrl) window.open(pdfUrl, '_blank', 'noopener,noreferrer')
              }}
            >
              {t('pdfOpenInNewTab')}
            </button>
          </>
        ) : undefined
      }
      onClose={closeFilePreview}
    >
      {loading ? <div className={styles.status}>{t('filePreviewLoading')}</div> : null}
      {error ? <div className={styles.status}>{t('filePreviewFailed')}</div> : null}
      {!loading && !error ? (
        <>
          {pdf && pdfMode === 'pdfjs' && pdfUrl ? (
            <PdfViewer url={pdfUrl} onError={handlePdfError} onLimited={handlePdfLimited} />
          ) : null}
          {pdf && pdfMode === 'native' && pdfUrl ? (
            <iframe
              className={styles.pdfFrame}
              title={request.name}
              src={pdfUrl}
              referrerPolicy="no-referrer"
              allow="fullscreen"
            />
          ) : null}
          {pdf && pdfMode === 'pdfjs' && pdfError ? (
            <div className={styles.status}>{t('filePreviewFailed')}</div>
          ) : null}
          {pdf && pdfLimited ? (
            <div className={styles.status}>{t('pdfPageLimit', { count: 50 })}</div>
          ) : null}
          {rasterImage ? (
            imageUrl ? (
              <div className={styles.imageWrap}>
                <img className={styles.image} src={imageUrl} alt={request.name} />
              </div>
            ) : null
          ) : null}
          {!rasterImage && runnable ? (
            <div className={styles.tabs}>
              <button
                type="button"
                className={mode === 'preview' ? styles.tabActive : styles.tab}
                onClick={() => setMode('preview')}
              >
                {t('preview')}
              </button>
              <button
                type="button"
                className={mode === 'source' ? styles.tabActive : styles.tab}
                onClick={() => setMode('source')}
              >
                {t('sourceCode')}
              </button>
            </div>
          ) : null}
          {!pdf && !rasterImage && runnable && mode === 'preview' ? (
            <iframe
              className={styles.frame}
              title={request.name}
              sandbox="allow-scripts allow-forms"
              referrerPolicy="no-referrer"
              srcDoc={
                ext === 'svg'
                  ? `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:16px;background:#fff}svg{max-width:100%;height:auto;display:block;margin:0 auto}</style></head><body>${text}</body></html>`
                  : text
              }
            />
          ) : !pdf && !rasterImage ? (
            <pre className={styles.code}>{text}</pre>
          ) : null}
          {truncated ? <div className={styles.status}>{t('filePreviewTruncated')}</div> : null}
        </>
      ) : null}
    </Modal>
  )
}
