import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useTranslate, type TranslationKey } from '../../i18n/index.js'
import { getVisibleMessages } from '../../services/chat/branches.js'
import * as db from '../../services/chat/db.js'
import { selectSession, useChatStore } from '../../services/chat/store.js'
import type { Message, Session } from '../../services/chat/types.js'
import { IconCloseOutline16, IconSearchOutline16 } from '../base/icons.js'
import { closeChatSearch, useChatSearch } from './chatSearchState.js'
import styles from './ChatSearch.module.css'

type SearchResult = {
  key: string
  sessionId: string
  messageId: string
  title: string
  snippet: string
  createdAt: number
}

const messageText = (message: Message): string => {
  if (message.role === 'user') {
    return message.content
  }
  return message.blocks
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('\n')
}

const dayLabel = (createdAt: number, t: (key: TranslationKey) => string) => {
  const today = new Date().setHours(0, 0, 0, 0)
  const day = new Date(createdAt).setHours(0, 0, 0, 0)
  const diff = Math.round((today - day) / 86_400_000)
  if (diff <= 0) return t('sessionHistoryTimelineLabelToday')
  if (diff === 1) return t('sessionHistoryTimelineLabelYesterday')
  const date = new Date(createdAt)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(
    date.getDate()
  ).padStart(2, '0')}`
}

const makeSnippet = (text: string, term: string) => {
  const flat = text.replace(/\s+/g, ' ').trim()
  const index = flat.toLocaleLowerCase().indexOf(term.toLocaleLowerCase())
  if (index < 0) return ''
  const start = Math.max(0, index - 36)
  const end = Math.min(flat.length, index + term.length + 76)
  return `${start > 0 ? '…' : ''}${flat.slice(start, end)}${end < flat.length ? '…' : ''}`
}

const Highlight = ({ text, term }: { text: string; term: string }) => {
  if (!term) return <>{text}</>
  const lower = text.toLocaleLowerCase()
  const needle = term.toLocaleLowerCase()
  const parts: React.ReactNode[] = []
  let cursor = 0
  let index = lower.indexOf(needle)
  while (index >= 0) {
    if (index > cursor) parts.push(text.slice(cursor, index))
    parts.push(<mark key={`${index}-${cursor}`}>{text.slice(index, index + term.length)}</mark>)
    cursor = index + term.length
    index = lower.indexOf(needle, cursor)
  }
  if (cursor < text.length) parts.push(text.slice(cursor))
  return <>{parts}</>
}

/** 本地聊天记录搜索：只读 IndexedDB/当前内存缓存，不请求服务端，只匹配消息文字。 */
export const ChatSearch = () => {
  const t = useTranslate()
  const open = useChatSearch((state) => state.open)
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const cacheRef = useRef(new Map<string, Session | null>())

  useEffect(() => {
    if (!open) return
    cacheRef.current.clear()
    setQuery('')
    setResults([])
    setLoading(false)
    const timer = window.setTimeout(() => inputRef.current?.focus(), 40)
    return () => window.clearTimeout(timer)
  }, [open])

  useEffect(() => {
    if (!open) return
    const term = query.trim()
    if (!term) {
      setResults([])
      setLoading(false)
      return
    }
    let active = true
    setLoading(true)
    const timer = window.setTimeout(async () => {
      const summaries = useChatStore.getState().sessions
      const lower = term.toLocaleLowerCase()
      const found: SearchResult[] = []
      for (const summary of summaries) {
        if (!active) return
        let session: Session | null | undefined =
          useChatStore.getState().sessionCache[summary.id] ?? cacheRef.current.get(summary.id)
        if (session === undefined) {
          session = (await db.loadSession(summary.id)) ?? null
          cacheRef.current.set(summary.id, session)
        }
        if (!session) continue
        // 会话分组保持不变；同一会话内从最近的消息向更早的消息排列。
        const messages = getVisibleMessages(session)
        for (let index = messages.length - 1; index >= 0; index -= 1) {
          const message = messages[index]
          const text = messageText(message)
          if (!text || !text.toLocaleLowerCase().includes(lower)) continue
          found.push({
            key: `${summary.id}:${message.id}`,
            sessionId: summary.id,
            messageId: message.id,
            title: summary.title || session.title || t('untitledChat'),
            snippet: makeSnippet(text, term),
            createdAt: message.createdAt || summary.updatedAt,
          })
          if (found.length >= 80) break
        }
        if (found.length >= 80) break
      }
      if (active) {
        setResults(found)
        setLoading(false)
      }
    }, 140)
    return () => {
      active = false
      window.clearTimeout(timer)
    }
  }, [open, query, t])

  if (!open) return null

  const jump = (result: SearchResult) => {
    closeChatSearch()
    selectSession(result.sessionId)
    const deadline = Date.now() + 3000
    const tryScroll = () => {
      window.dispatchEvent(new CustomEvent('chat:reveal-message', { detail: result.messageId }))
      const el = document.querySelector<HTMLElement>(
        `[data-message-id="${CSS.escape(result.messageId)}"]`
      )
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' })
        el.animate(
          [
            { backgroundColor: 'rgba(79, 124, 255, 0.18)' },
            { backgroundColor: 'transparent' },
          ],
          { duration: 1500, easing: 'ease-out' }
        )
        return
      }
      if (Date.now() < deadline) window.setTimeout(tryScroll, 80)
    }
    window.requestAnimationFrame(tryScroll)
  }

  return createPortal(
    <div
      className={styles.overlay}
      onMouseDown={(event) => event.target === event.currentTarget && closeChatSearch()}
    >
      <div className={styles.panel} role="dialog" aria-modal="true" aria-label={t('searchChats')}>
        <div className={styles.inputRow}>
          <IconSearchOutline16 />
          <input
            ref={inputRef}
            className={styles.input}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t('searchChatPlaceholder')}
            aria-label={t('searchChatPlaceholder')}
            autoComplete="off"
            spellCheck={false}
            onKeyDown={(event) => {
              if (event.key === 'Escape') closeChatSearch()
              if (event.key === 'Enter' && results[0]) {
                event.preventDefault()
                jump(results[0])
              }
            }}
          />
          <button
            type="button"
            className={styles.close}
            aria-label={t('close')}
            onClick={closeChatSearch}
          >
            <IconCloseOutline16 />
          </button>
        </div>
        <div className={styles.results}>
          {!query.trim() ? (
            <div className={styles.hint}>{t('searchChatHint')}</div>
          ) : loading ? (
            <div className={styles.hint}>{t('searchChatLoading')}</div>
          ) : results.length === 0 ? (
            <div className={styles.hint}>{t('searchChatNoResults')}</div>
          ) : (
            <>
              <div className={styles.count}>{t('searchChatResultCount', { count: results.length })}</div>
              {results.map((result) => (
                <button
                  key={result.key}
                  type="button"
                  className={styles.result}
                  onClick={() => jump(result)}
                >
                  <span className={styles.avatar} aria-hidden>
                    <IconSearchOutline16 />
                  </span>
                  <span className={styles.resultBody}>
                    <span className={styles.resultTitle}>{result.title}</span>
                    <span className={styles.snippet}>
                      <Highlight text={result.snippet} term={query.trim()} />
                    </span>
                  </span>
                  <span className={styles.date}>{dayLabel(result.createdAt, t)}</span>
                </button>
              ))}
            </>
          )}
        </div>
      </div>
    </div>,
    document.body
  )
}
