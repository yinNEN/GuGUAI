import { create } from 'zustand'

/** 聊天记录搜索弹窗：只控制开合，关键词和结果保存在组件内。 */
type ChatSearchState = {
  open: boolean
}

export const useChatSearch = create<ChatSearchState>(() => ({ open: false }))

export const openChatSearch = () => useChatSearch.setState({ open: true })
export const closeChatSearch = () => useChatSearch.setState({ open: false })
