import clsx from 'clsx'
import { useEffect, useMemo, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import {
  IconCheckOutline16,
  IconCloseOutline16,
  IconPanelLeftOutline16,
  IconSearchOutline16,
  IconSettingsOutline16,
  IconTrashOutline16,
  NewChatIcon,
} from '../base/icons.js'
import { setSiderCollapsed } from '../../services/settings.js'
import { groupSessions } from '../../services/chat/sessionGroups.js'
import { newChat, removeSession, useChatStore } from '../../services/chat/store.js'
import type { SessionSummary } from '../../services/chat/types.js'
import { Button } from '../base/Button.js'
import { IconButton } from '../base/IconButton.js'
import { Modal } from '../base/Modal.js'
import { showToast } from '../base/toastState.js'
import { openSettings } from '../settings/settingsDialogState.js'
import { openChatSearch } from '../search/chatSearchState.js'
import { useBranding } from '../../services/branding.js'
import { closeMobileSider, useMobileSider } from './mobileSiderState.js'
import { SessionItem } from './SessionItem.js'
import styles from './Sider.module.css'

/** 展开的侧边栏：名称与收起按钮、开启新对话、按时间分组的会话列表、底部设置；移动端放在抽屉里，收起按钮关闭抽屉 */
export const Sider = ({ mobile = false }: { mobile?: boolean }) => {
  const t = useTranslate()
  const branding = useBranding()
  const brandTitle = branding.title || t('appName')
  const brandSubtitle = branding.subtitle || t('appTagline')
  const sessions = useChatStore((state) => state.sessions)
  const activeId = useChatStore((state) => state.activeId)
  const [now, setNow] = useState(Date.now)
  const groups = useMemo(() => groupSessions(sessions, now, t), [sessions, now, t])
  const [deleting, setDeleting] = useState<SessionSummary | null>(null)
  const [deletePending, setDeletePending] = useState(false)
  const [selectMode, setSelectMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(() => new Set())
  const [batchDeleting, setBatchDeleting] = useState(false)
  const [confirmBatch, setConfirmBatch] = useState(false)

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>
    const refresh = () => {
      clearTimeout(timer)
      const time = Date.now()
      setNow(time)
      const midnight = new Date(time).setHours(24, 0, 0, 0)
      timer = setTimeout(refresh, midnight - time)
    }
    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        refresh()
      }
    }
    refresh()
    document.addEventListener('visibilitychange', onVisibilityChange)
    window.addEventListener('focus', refresh)
    return () => {
      clearTimeout(timer)
      document.removeEventListener('visibilitychange', onVisibilityChange)
      window.removeEventListener('focus', refresh)
    }
  }, [])

  const exitSelect = () => {
    setSelectMode(false)
    setSelected(new Set())
    setConfirmBatch(false)
  }
  const toggleSelect = (id: string) => {
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }
  const deleteSelected = async () => {
    const ids = [...selected]
    if (!ids.length) return
    setBatchDeleting(true)
    try {
      let removed = 0
      for (const id of ids) {
        if (await removeSession(id)) removed += 1
      }
      setConfirmBatch(false)
      setSelected(new Set())
      setSelectMode(false)
      if (removed === ids.length) {
        showToast({ key: 'selectedChatsDeleted', params: { count: removed } })
      } else {
        showToast({ key: 'sessionDeleteFailed', type: 'error' })
      }
    } finally {
      setBatchDeleting(false)
    }
  }

  return (
    <div className={clsx(styles.sider, mobile && styles.mobile, selectMode && styles.selecting)}>
      {selectMode ? (
        <div className={styles.multiHeader}>
          <div className={styles.multiTitle}>{t('selectChats')}</div>
          <button
            type="button"
            className={clsx(styles.selectAll, selected.size === sessions.length && sessions.length > 0 && styles.selectAllChecked)}
            aria-label={selected.size === sessions.length && sessions.length > 0 ? t('deselectAllChats') : t('selectAllChats')}
            title={selected.size === sessions.length && sessions.length > 0 ? t('deselectAllChats') : t('selectAllChats')}
            onClick={() => {
              if (selected.size === sessions.length && sessions.length > 0) setSelected(new Set())
              else setSelected(new Set(sessions.map((session) => session.id)))
            }}
          >
            {selected.size === sessions.length && sessions.length > 0 ? <IconCheckOutline16 /> : null}
          </button>
          <IconButton
            size="m"
            icon={<IconCloseOutline16 />}
            tooltip={t('exitSelection')}
            aria-label={t('exitSelection')}
            onClick={exitSelect}
          />
        </div>
      ) : (
        <>
          <div className={styles.top}>
            {branding.markMode !== 'none' ? (
              <div
                className={styles.brandMark}
                style={{ fontSize: (branding.mark || 'G').length > 2 ? 12 : undefined }}
                aria-hidden
              >
                {branding.markMode === 'image' && branding.markImage ? (
                  <img src={branding.markImage} alt="" />
                ) : (
                  branding.mark || 'G'
                )}
              </div>
            ) : null}
            <div className={styles.brandText}>
              <div className={styles.appName}>{brandTitle}</div>
              <div className={styles.appTagline}>{brandSubtitle}</div>
            </div>
            <div className={styles.topActions}>
              <IconButton
                size="m"
                icon={<IconSearchOutline16 />}
                tooltip={t('searchChats')}
                tooltipPlacement="bottom"
                onClick={openChatSearch}
              />
              <IconButton
                size="m"
                icon={<IconPanelLeftOutline16 />}
                tooltip={t('collapseSiderbarButton')}
                tooltipPlacement="bottom"
                onClick={() => (mobile ? closeMobileSider() : setSiderCollapsed(true))}
              />
            </div>
          </div>
          <button
            type="button"
            className={styles.newChat}
            onClick={() => {
              newChat()
              closeMobileSider()
            }}
          >
            <span className={styles.newChatIcon}>
              <NewChatIcon />
            </span>
            {t('newChat')}
          </button>
        </>
      )}
      <div className={styles.listWrap}>
        <div className={styles.list}>
          {groups.map((group) => (
            <div key={group.key} className={styles.section}>
              <div className={styles.sectionHeader}>{group.label}</div>
              {group.sessions.map((session) => (
                <SessionItem
                  key={session.id}
                  session={session}
                  active={session.id === activeId}
                  onDelete={() => setDeleting(session)}
                  selectable={selectMode}
                  selected={selected.has(session.id)}
                  onToggleSelect={() => toggleSelect(session.id)}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
      {selectMode ? (
        <div className={styles.multiBottom}>
          <span className={styles.multiCount}>{t('selectedChatsCount', { count: selected.size })}</span>
          <button
            type="button"
            className={styles.multiDelete}
            disabled={selected.size === 0 || batchDeleting}
            onClick={() => setConfirmBatch(true)}
          >
            <IconTrashOutline16 />
            {t('deleteSelectedChats')}
          </button>
        </div>
      ) : (
        <div className={styles.bottomActions}>
          <button
            type="button"
            className={styles.bottomAction}
            aria-label={t('selectChats')}
            onClick={() => {
              setSelectMode(true)
              setSelected(new Set())
            }}
          >
            <span className={styles.settingsIcon}>
              <IconCheckOutline16 />
            </span>
            <span className={styles.settingsLabel}>{t('selectChats')}</span>
          </button>
          <button type="button" className={styles.bottomAction} onClick={() => openSettings('general')}>
            <span className={styles.settingsIcon}>
              <IconSettingsOutline16 />
            </span>
            <span className={styles.settingsLabel}>{t('settings')}</span>
          </button>
        </div>
      )}
      {confirmBatch ? (
        <Modal
          title={t('deleteSelectedChatsTitle')}
          onClose={() => {
            if (!batchDeleting) setConfirmBatch(false)
          }}
          footer={
            <>
              <Button variant="outlined" disabled={batchDeleting} onClick={() => setConfirmBatch(false)}>
                {t('cancel')}
              </Button>
              <Button variant="danger" disabled={batchDeleting} onClick={() => void deleteSelected()}>
                {t(batchDeleting ? 'batchDeleting' : 'delete')}
              </Button>
            </>
          }
        >
          {t('deleteSelectedChatsDescription', { count: selected.size })}
        </Modal>
      ) : null}
      {deleting ? (
        <Modal
          title={t('deleteSessionModalContentTitle')}
          onClose={() => {
            if (!deletePending) {
              setDeleting(null)
            }
          }}
          footer={
            <>
              <Button variant="outlined" disabled={deletePending} onClick={() => setDeleting(null)}>
                {t('cancel')}
              </Button>
              <Button
                variant="danger"
                disabled={deletePending}
                onClick={async () => {
                  setDeletePending(true)
                  try {
                    if (await removeSession(deleting.id)) {
                      setDeleting(null)
                    } else {
                      showToast({ key: 'sessionDeleteFailed', type: 'error' })
                    }
                  } finally {
                    setDeletePending(false)
                  }
                }}
              >
                {t('delete')}
              </Button>
            </>
          }
        >
          {t('deleteSessionWithFilesDescription')}
        </Modal>
      ) : null}
    </div>
  )
}

/** 移动端抽屉：浮在页面上方，点空白区域关闭。 */
export const MobileSider = () => {
  const open = useMobileSider((state) => state.open)
  if (!open) {
    return null
  }
  return (
    <>
      <div className={styles.drawerMask} onClick={closeMobileSider} />
      <div className={styles.drawer}>
        <Sider mobile />
      </div>
    </>
  )
}
