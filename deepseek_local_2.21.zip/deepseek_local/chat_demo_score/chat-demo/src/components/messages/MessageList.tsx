import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useIsMobile } from '../../app/viewport.js'
import { useTranslate } from '../../i18n/index.js'
import {
  buildMessageVersions,
  getVisibleMessages,
  type MessageVersions,
} from '../../services/chat/branches.js'
import { selectMessageVersion } from '../../services/chat/store.js'
import type { Session } from '../../services/chat/types.js'
import { closeSearchPanel } from '../search/searchPanelState.js'
import { AssistantMessage } from './AssistantMessage.js'
import { JumpRail } from './JumpRail.js'
import { ScrollToBottomContext } from './scrollContext.js'
import { UserMessage } from './UserMessage.js'
import type { Message } from '../../services/chat/types.js'

/**
 * 会话共用可重试的附件上传失败入口，覆盖当前提问与历史消息中的附件。
 * 点击后按失败的回答重新补传附件并请求。
 */
const getUploadRetryId = (messages: Message[], streaming: boolean) => {
  const last = messages.at(-1)
  return !streaming &&
    last?.role === 'assistant' &&
    last.status === 'error' &&
    last.error?.kind === 'upload' &&
    last.error.retryable
    ? last.id
    : null
}
import styles from './MessageList.module.css'

/** 距底部小于该值时视为在底部，流式内容增长时跟随 */
const STICKY_THRESHOLD = 40
/** 初始只渲染靠近底部的消息，向上滚动时再分批加载；避免超大聊天一次性渲染全部 Markdown */
const INITIAL_RENDER = 24
const LOAD_CHUNK = 16
const LOAD_EARLIER_THRESHOLD = 260
const EMPTY_VERSIONS: MessageVersions = { ids: [], index: -1 }

export const MessageList = ({
  session,
  streaming,
  footer,
}: {
  session: Session
  streaming: boolean
  footer: React.ReactNode
}) => {
  const t = useTranslate()
  const isMobile = useIsMobile()
  const scrollRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const stickyRef = useRef(true)
  const scrollTopRef = useRef(0)
  const suppressLoadRef = useRef(false)
  const restoreScrollRef = useRef<{ messageId: string; top: number } | null>(null)
  const messages = getVisibleMessages(session)
  const [renderStart, setRenderStart] = useState(() =>
    Math.max(0, messages.length - INITIAL_RENDER)
  )
  const [renderEnd, setRenderEnd] = useState(messages.length)
  const [revealId, setRevealId] = useState<string | null>(null)
  const [revealing, setRevealing] = useState(false)
  const previousLength = useRef(messages.length)
  const prependRef = useRef<{ height: number; top: number } | null>(null)
  const [previousVersions, setPreviousVersions] = useState(() =>
    buildMessageVersions(session, new Map())
  )
  const versions = useMemo(
    () => buildMessageVersions(session, previousVersions),
    [session, previousVersions]
  )
  if (versions !== previousVersions) {
    setPreviousVersions(versions)
  }
  const lastMessageId = messages.at(-1)?.id
  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current
    if (el && stickyRef.current) {
      el.scrollTop = el.scrollHeight
      scrollTopRef.current = el.scrollTop
    }
  }, [])

  const loadEarlier = useCallback(() => {
    const el = scrollRef.current
    if (!el || renderStart <= 0) return
    prependRef.current = { height: el.scrollHeight, top: el.scrollTop }
    setRenderStart((start) => Math.max(0, start - LOAD_CHUNK))
  }, [renderStart])

  const loadLater = useCallback(() => {
    setRenderEnd((end) => Math.min(messages.length, end + LOAD_CHUNK))
  }, [messages.length])

  // 流式/新消息追加时，如果窗口原本贴到底部，则同步扩展到底部
  useEffect(() => {
    const previous = previousLength.current
    previousLength.current = messages.length
    setRenderEnd((end) => (end === previous ? messages.length : Math.min(end, messages.length)))
  }, [messages.length])

  // 向上/向下接近边缘时自动加载；侧边栏宽度动画期间暂停，
  // 否则一次收展动画产生的 scroll 事件会连续展开多段历史，低端设备会卡顿。
  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => {
      if (suppressLoadRef.current) return
      if (el.scrollTop < LOAD_EARLIER_THRESHOLD) loadEarlier()
      else if (el.scrollHeight - el.scrollTop - el.clientHeight < LOAD_EARLIER_THRESHOLD) loadLater()
    }
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [loadEarlier, loadLater])

  useLayoutEffect(() => {
    const anchor = prependRef.current
    const el = scrollRef.current
    if (anchor && el) {
      el.scrollTop = el.scrollHeight - anchor.height + anchor.top
      scrollTopRef.current = el.scrollTop
    }
    prependRef.current = null
  }, [renderStart])

  // 搜索结果/跳转条需要显示窗口外的旧消息时，扩大渲染窗口并在布局完成后定位。
  useEffect(() => {
    const reveal = (event: Event) => {
      const id = (event as CustomEvent<string>).detail
      const index = messages.findIndex((message) => message.id === id)
      if (index < 0) return
      // 定位期间关闭“跟随底部”，否则 ResizeObserver 会把刚展开的旧消息又拉回底部。
      stickyRef.current = false
      setRevealing(true)
      setRevealId(id)
      // 始终围绕目标保留一个固定窗口，不能把窗口反向扩张成“从顶部到底部”。
      setRenderStart(Math.max(0, index - 6))
      setRenderEnd(Math.min(messages.length, index + 18))
    }
    window.addEventListener('chat:reveal-message', reveal)
    return () => window.removeEventListener('chat:reveal-message', reveal)
  }, [messages])

  useLayoutEffect(() => {
    if (!revealId) return undefined
    const scroll = scrollRef.current
    const node = scroll?.querySelector<HTMLElement>(
      `[data-message-id="${CSS.escape(revealId)}"]`
    )
    if (!scroll || !node) {
      const timer = window.setTimeout(() => {
        setRevealId(null)
        setRevealing(false)
      }, 2000)
      return () => window.clearTimeout(timer)
    }
    const delta = node.getBoundingClientRect().top - scroll.getBoundingClientRect().top
    scroll.scrollTop += delta - 12
    scrollTopRef.current = scroll.scrollTop
    setRevealId(null)
    // 至少展示一小段等待提示，避免快速设备上闪烁；不影响实际滚动
    window.setTimeout(() => setRevealing(false), 150)
    return undefined
  }, [revealId, renderStart, renderEnd])

  // 内容、键盘和输入框高度变化时，继续遵循当前跟随状态。
  useLayoutEffect(() => {
    const content = contentRef.current
    const scroll = scrollRef.current
    if (!content || !scroll) {
      return
    }
    let frame = 0
    let lastWidth = scroll.clientWidth
    let suppressTimer = 0
    const scheduleFollow = () => {
      if (scroll.clientWidth !== lastWidth) {
        lastWidth = scroll.clientWidth
        suppressLoadRef.current = true
        window.clearTimeout(suppressTimer)
        suppressTimer = window.setTimeout(() => {
          suppressLoadRef.current = false
        }, 120)
      }
      if (frame) return
      frame = requestAnimationFrame(() => {
        frame = 0
        scrollToBottom()
      })
    }
    const observer = new ResizeObserver(scheduleFollow)
    observer.observe(content)
    observer.observe(scroll)
    return () => {
      observer.disconnect()
      window.clearTimeout(suppressTimer)
      suppressLoadRef.current = false
      if (frame) cancelAnimationFrame(frame)
    }
  }, [isMobile, scrollToBottom])

  // 切换版本后将选择器留在原位置，避免回答长短变化导致操作区跳出视口。
  useLayoutEffect(() => {
    const anchor = restoreScrollRef.current
    const scroll = scrollRef.current
    if (anchor && scroll) {
      const switcher = scroll.querySelector<HTMLElement>(
        `[data-message-version="${CSS.escape(anchor.messageId)}"]`
      )
      if (switcher) {
        scroll.scrollTop += switcher.getBoundingClientRect().top - anchor.top
      }
      restoreScrollRef.current = null
      return
    }
    stickyRef.current = true
    scrollToBottom()
  }, [session.id, lastMessageId, scrollToBottom])

  useEffect(closeSearchPanel, [session.id, lastMessageId])

  const selectVersion = useCallback(
    (messageId: string, anchorTop: number) => {
      if (streaming) {
        return
      }
      restoreScrollRef.current = { messageId, top: anchorTop }
      stickyRef.current = false
      closeSearchPanel()
      selectMessageVersion(session.id, messageId)
    },
    [session.id, streaming]
  )

  // 跨移动端断点时切换滚动层，并保持输入框及当前阅读位置。
  useLayoutEffect(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    if (stickyRef.current) {
      scrollToBottom()
    } else {
      el.scrollTop = scrollTopRef.current
    }
    const onScroll = () => {
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < STICKY_THRESHOLD
      // 仅在用户向上滚动时停止跟随底部，布局或内容增高时保持跟随状态。
      if (nearBottom) {
        stickyRef.current = true
      } else if (el.scrollTop < scrollTopRef.current) {
        stickyRef.current = false
      }
      scrollTopRef.current = el.scrollTop
    }
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [isMobile, scrollToBottom])

  const lastIndex = messages.length - 1
  const uploadRetryId = getUploadRetryId(messages, streaming)
  const renderedMessages = messages.slice(renderStart, renderEnd)
  return (
    <ScrollToBottomContext.Provider value={scrollToBottom}>
      <div ref={isMobile ? undefined : scrollRef} className={styles.container}>
        <div ref={isMobile ? scrollRef : undefined} className={styles.scroll}>
          <div ref={contentRef} className={styles.column}>
            {renderStart > 0 ? (
              <div className={styles.loadEarlier}>
                <button type="button" onClick={loadEarlier}>
                  {t('loadEarlierMessages')}
                </button>
              </div>
            ) : null}
            {renderedMessages.map((message, localIndex) => {
              const index = renderStart + localIndex
              return message.role === 'user' ? (
                <UserMessage
                  key={message.id}
                  sessionId={session.id}
                  message={message}
                  retryUploadId={uploadRetryId}
                  isFirst={index === 0}
                  isLast={index === lastIndex || index === lastIndex - 1}
                  busy={streaming}
                  versions={versions.get(message.id) ?? EMPTY_VERSIONS}
                  onSelectVersion={selectVersion}
                />
              ) : (
                <AssistantMessage
                  key={message.id}
                  sessionId={session.id}
                  message={message}
                  isLast={index === lastIndex}
                  streaming={streaming && index === lastIndex}
                  busy={streaming}
                  versions={versions.get(message.id) ?? EMPTY_VERSIONS}
                  onSelectVersion={selectVersion}
                />
              )
            })}
            {renderEnd < messages.length ? (
              <div className={styles.loadEarlier}>
                <button type="button" onClick={loadLater}>
                  {t('loadLaterMessages')}
                </button>
              </div>
            ) : null}
          </div>
        </div>
        {revealing ? (
          <div className={styles.revealOverlay} role="status" aria-live="polite">
            <span className={styles.revealSpinner} />
            {t('locatingMessage')}
          </div>
        ) : null}
        {footer}
        <JumpRail session={session} messages={messages} scrollRef={scrollRef} />
      </div>
    </ScrollToBottomContext.Provider>
  )
}
