import { useEffect, useRef, useState } from 'react'
import type { RefObject } from 'react'
import type { Message, Session } from '../../services/chat/types.js'
import { useTranslate } from '../../i18n/index.js'
import styles from './JumpRail.module.css'

const previewText = (message: Message) =>
  (message.role === 'user' ? message.content : '').replace(/\s+/g, ' ').trim()

/**
 * 右侧提问跳转条，交互对齐 DeepSeek 官方聊天：
 * - 默认只显示短横线，但每行有足够大的可点击区域；
 * - 鼠标移入展开问题列表，列表可滚动；
 * - 点击问题文字或短横线都能跳转到对应消息。
 */
export const JumpRail = ({
  session,
  messages,
  scrollRef,
}: {
  session: Session
  messages: Message[]
  scrollRef: RefObject<HTMLDivElement | null>
}) => {
  const t = useTranslate()
  const [activeId, setActiveId] = useState<string | null>(null)
  const [open, setOpen] = useState(false)
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const users = messages.filter((message) => message.role === 'user')

  useEffect(() => {
    const scroll = scrollRef.current
    if (!scroll) {
      return
    }
    let frame = 0
    const update = () => {
      frame = 0
      const nodes = scroll.querySelectorAll<HTMLElement>('[data-message-id]')
      const top = scroll.getBoundingClientRect().top
      let current: string | null = null
      nodes.forEach((node) => {
        if (node.getBoundingClientRect().top - top <= 96) {
          current = node.dataset.messageId ?? null
        }
      })
      setActiveId(current)
    }
    const onScroll = () => {
      if (!frame) {
        frame = requestAnimationFrame(update)
      }
    }
    scroll.addEventListener('scroll', onScroll, { passive: true })
    update()
    return () => {
      scroll.removeEventListener('scroll', onScroll)
      if (frame) {
        cancelAnimationFrame(frame)
      }
    }
  }, [scrollRef, users.length, session.id])

  // 展开时把当前消息滚到列表可见区域
  useEffect(() => {
    if (!open || !activeId) {
      return
    }
    const row = panelRef.current?.querySelector<HTMLElement>(
      `[data-jump-id="${CSS.escape(activeId)}"]`
    )
    row?.scrollIntoView({ block: 'nearest' })
  }, [open, activeId])

  if (users.length < 2) {
    return null
  }

  const jumpTo = (id: string) => {
    // 由 MessageList 统一展开渲染窗口并定位，避免 ResizeObserver 把定位拉回底部。
    window.dispatchEvent(new CustomEvent('chat:reveal-message', { detail: id }))
  }

  const scheduleClose = () => {
    if (closeTimer.current) {
      clearTimeout(closeTimer.current)
    }
    closeTimer.current = setTimeout(() => {
      setOpen(false)
      setHoveredId(null)
    }, 160)
  }

  const cancelClose = () => {
    if (closeTimer.current) {
      clearTimeout(closeTimer.current)
      closeTimer.current = null
    }
    setOpen(true)
  }

  return (
    <div
      className={styles.wrap}
      onMouseEnter={cancelClose}
      onMouseLeave={scheduleClose}
    >
      <div className={`${styles.rail} ${open ? styles.railHidden : ''}`} aria-hidden={open}>
        {users.map((message, index) => (
          <button
            key={message.id}
            type="button"
            className={`${styles.markButton} ${
              activeId === message.id ? styles.markButtonActive : ''
            }`}
            aria-label={t('jumpRailUserMessage', { index: index + 1 })}
            onClick={() => jumpTo(message.id)}
          >
            <span className={styles.mark} />
          </button>
        ))}
      </div>

      {open ? (
        <div className={styles.panel} role="dialog" aria-label={t('jumpRailTitle')}>
          <div ref={panelRef} className={styles.panelList}>
            {users.map((message) => {
              const text = previewText(message)
              return (
                <button
                  key={message.id}
                  type="button"
                  data-jump-id={message.id}
                  className={`${styles.panelRow} ${
                    activeId === message.id ? styles.panelRowActive : ''
                  } ${hoveredId === message.id ? styles.panelRowHover : ''}`}
                  onMouseEnter={() => setHoveredId(message.id)}
                  onMouseLeave={() => setHoveredId((current) => (current === message.id ? null : current))}
                  onClick={() => jumpTo(message.id)}
                  title={text || t('jumpRailAttachment')}
                >
                  <span className={styles.panelText}>
                    {text.slice(0, 160) || t('jumpRailAttachment')}
                  </span>
                  <span className={styles.panelMark} />
                </button>
              )
            })}
          </div>
        </div>
      ) : null}
    </div>
  )
}
