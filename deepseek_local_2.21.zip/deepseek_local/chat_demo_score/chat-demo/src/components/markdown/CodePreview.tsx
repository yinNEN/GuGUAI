import { useTranslate } from '../../i18n/index.js'
import { closeCodePreview, useCodePreview } from '../../services/codePreview.js'
import { Modal } from '../base/Modal.js'
import styles from './CodePreview.module.css'

// SVG 直接内联到 HTML 文档中：HTML 解析器容错更好，也能让 SVG 自适应 iframe。
// 之前用 <img src="data:image/svg+xml,...">，部分 SVG 在沙箱 iframe 中会因资源加载策略显示空白。
const svgDocument = (code: string) =>
  `<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#fff}
body{padding:16px;display:flex;justify-content:center;align-items:flex-start;min-height:100%}
svg{max-width:100%;height:auto;display:block}
</style></head><body>${code}</body></html>`

/** 在隔离 iframe 中运行模型生成的 HTML/SVG（禁用同源，避免影响本站） */
export const CodePreview = () => {
  const t = useTranslate()
  const request = useCodePreview((state) => state.request)
  if (!request) {
    return null
  }
  const language = request.language.toLowerCase()
  const document =
    language === 'svg' ? svgDocument(request.code) : request.code
  return (
    <Modal
      title={t('codePreviewTitle')}
      closable
      className={styles.modal}
      mainClassName={styles.main}
      onClose={closeCodePreview}
    >
      <iframe
        className={styles.frame}
        title={t('codePreviewTitle')}
        sandbox="allow-scripts allow-forms"
        referrerPolicy="no-referrer"
        srcDoc={document}
      />
    </Modal>
  )
}
