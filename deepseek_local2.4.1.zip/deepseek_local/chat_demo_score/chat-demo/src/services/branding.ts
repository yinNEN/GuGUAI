import { create } from 'zustand'

export type Branding = {
  title: string
  subtitle: string
  mark: string
  color: string
  markMode: 'text' | 'image' | 'none'
  markImage: string
}

const DEFAULT_BRANDING: Branding = {
  title: '',
  subtitle: '',
  mark: 'G',
  color: '#4d6bfe',
  markMode: 'text',
  markImage: '',
}

type BrandingState = Branding & { loaded: boolean }

export const useBranding = create<BrandingState>(() => ({ ...DEFAULT_BRANDING, loaded: false }))

const escapeXml = (value: string) =>
  value.replace(/[<>&"']/g, (char) => {
    switch (char) {
      case '<': return '&lt;'
      case '>': return '&gt;'
      case '&': return '&amp;'
      case '"': return '&quot;'
      default: return '&apos;'
    }
  })

/** 浏览器标签页图标：图片品牌用服务端图标，文字品牌生成同色 SVG，关闭品牌标识时恢复默认。 */
const applyFavicon = (branding: Branding) => {
  let link = document.querySelector<HTMLLinkElement>('link[rel~="icon"]')
  if (branding.markMode === 'none') {
    link?.remove()
    return
  }
  let href = ''
  let type = ''
  if (branding.markMode === 'image' && branding.markImage) {
    href = branding.markImage
  } else {
    const mark = escapeXml(branding.mark || 'G')
    const size = mark.length > 2 ? 20 : 30
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" rx="11" fill="${branding.color}"/><text x="24" y="25" text-anchor="middle" dominant-baseline="middle" fill="#fff" font-family="system-ui,sans-serif" font-size="${size}" font-weight="600">${mark}</text></svg>`
    href = `data:image/svg+xml,${encodeURIComponent(svg)}`
    type = 'image/svg+xml'
  }
  if (!link) {
    link = document.createElement('link')
    link.rel = 'icon'
    document.head.appendChild(link)
  }
  link.type = type
  link.href = href
}

const hexToRgb = (hex: string) => {
  const value = hex.replace('#', '')
  return [
    parseInt(value.slice(0, 2), 16),
    parseInt(value.slice(2, 4), 16),
    parseInt(value.slice(4, 6), 16),
  ]
}

/** 将品牌色写入现有主题变量；未配置/加载失败时保持原主题。 */
export const applyBranding = (branding: Branding) => {
  useBranding.setState({ ...branding, loaded: true })
  applyFavicon(branding)
  if (branding.title) document.title = branding.title
  if (branding.color) {
    const root = document.documentElement
    root.style.setProperty('--dsw-alias-brand-primary', branding.color)
    root.style.setProperty('--dsw-alias-brand-text', branding.color)
    root.style.setProperty('--dsw-alias-button-primary-fill', branding.color)
    const [r, g, b] = hexToRgb(branding.color)
    root.style.setProperty('--brand-soft', `rgba(${r}, ${g}, ${b}, 0.14)`)
  }
}

export const fetchBranding = async () => {
  try {
    const response = await fetch('/api/public/branding', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
    })
    if (!response.ok) return
    const data = (await response.json()) as Partial<Branding> & { mark_mode?: string; mark_image?: string }
    applyBranding({
      title: String(data.title || ''),
      subtitle: String(data.subtitle || ''),
      mark: String(data.mark || 'G').slice(0, 4),
      color: /^#[0-9a-fA-F]{6}$/.test(String(data.color || ''))
        ? String(data.color)
        : DEFAULT_BRANDING.color,
      markMode:
        (data.mark_mode === 'image' || data.mark_mode === 'none' ? data.mark_mode : 'text'),
      markImage: typeof data.mark_image === 'string' ? data.mark_image : '',
    })
  } catch {
    // 品牌配置读取失败不影响聊天
  }
}
