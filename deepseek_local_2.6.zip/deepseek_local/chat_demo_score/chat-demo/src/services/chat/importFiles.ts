import { uploadFile } from '../api/client.js'
import { getUploadPurpose } from '../attachments.js'
import type { Session } from './types.js'
import * as db from './db.js'

export type ImportFileResult = {
  sessions: Session[]
  uploaded: number
  skipped: number
  quotaHit: boolean
}

const MAX_IMPORT_FILE_BYTES = 32 * 1024 * 1024
const CONCURRENCY = 3

const existsOnServer = async (serverId: string): Promise<boolean> => {
  try {
    const response = await fetch(`/api/files/${encodeURIComponent(serverId)}`, {
      method: 'HEAD',
      credentials: 'same-origin',
    })
    return response.ok
  } catch {
    return false
  }
}

type ImportFile = {
  name: string
  isImage: boolean
  mimeType: string
  blob: Blob
  previousServerId: string | null
}

/**
 * 导入历史后，把归档里的本地原件上传到服务器：
 * - 图片进入文件缓冲区，文本/代码进入独立文本区；
 * - 单文件超过 32MB、服务端返回 413/507（配额）时跳过，不影响导入本身；
 * - 已有且服务端仍存在的 serverId 不重复上传。
 */
export const uploadImportedFiles = async (sessions: Session[]): Promise<ImportFileResult> => {
  const files = new Map<string, ImportFile>()
  for (const session of sessions) {
    for (const message of session.messages) {
      if (message.role !== 'user') {
        continue
      }
      for (const file of message.files) {
        if (files.has(file.id)) {
          continue
        }
        const blob = await db.loadFile(file.id).catch(() => undefined)
        if (!blob) {
          continue
        }
        files.set(file.id, {
          name: file.name,
          isImage: file.isImage,
          mimeType: file.mimeType || blob.type,
          blob,
          previousServerId: file.serverId,
        })
      }
    }
  }

  const results = new Map<string, string>()
  let uploaded = 0
  let skipped = 0
  let quotaHit = false
  let cursor = 0
  const entries = [...files.entries()]

  const worker = async () => {
    for (;;) {
      const index = cursor++
      if (index >= entries.length) {
        return
      }
      const [id, file] = entries[index]
      if (file.blob.size > MAX_IMPORT_FILE_BYTES) {
        skipped++
        continue
      }
      if (file.previousServerId && (await existsOnServer(file.previousServerId))) {
        results.set(id, file.previousServerId)
        continue
      }
      try {
        const upload = new File([file.blob], file.name, {
          type: file.mimeType || file.blob.type || 'application/octet-stream',
        })
        const result = await uploadFile(
          'managed-by-server',
          upload,
          getUploadPurpose(file.name, file.isImage)
        )
        results.set(id, result.id)
        uploaded++
      } catch (error) {
        if ((error as { status?: number }).status === 507) {
          quotaHit = true
        }
        skipped++
      }
    }
  }

  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, entries.length) }, worker))

  for (const session of sessions) {
    let changed = false
    for (const message of session.messages) {
      if (message.role !== 'user') {
        continue
      }
      for (const file of message.files) {
        const serverId = results.get(file.id)
        if (serverId && serverId !== file.serverId) {
          file.serverId = serverId
          if (file.isImage) {
            file.imageSizeChecked = true
          }
          changed = true
        }
      }
    }
    if (changed) {
      await db.saveSession(session).catch(() => {})
    }
  }

  return { sessions, uploaded, skipped, quotaHit }
}
