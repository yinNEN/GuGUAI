import { create } from 'zustand'
import { setChatDatabaseUser } from './chat/db.js'

/** 后端 /api/auth/me 返回的当前登录用户 */
export type ServerUser = {
  id: number
  username: string
  role: 'admin' | 'user'
  must_change_password?: boolean
}

type ServerSessionState = {
  user: ServerUser | null
  checked: boolean
}

export const useServerSession = create<ServerSessionState>(() => ({
  user: null,
  checked: false,
}))

/** 跳转后端登录页，登录后回到当前地址 */
export const redirectToLogin = () => {
  if (location.pathname === '/login') {
    return
  }
  const next = encodeURIComponent(location.pathname + location.search)
  location.replace(`/login?next=${next}`)
}

/** 退出登录：由后端清除 HttpOnly 会话并跳回登录页 */
export const logout = () => {
  location.href = '/logout'
}

/** 读取当前登录用户；未登录时跳转登录页。失败不阻塞界面启动。 */
export const initServerSession = async (): Promise<void> => {
  if (!__SERVER_MANAGED__) {
    setChatDatabaseUser(null)
    useServerSession.setState({ checked: true })
    return
  }
  // 认证完成前使用独立临时库，绝不能回退到旧版共享的 chat-demo 库
  setChatDatabaseUser('pending')
  try {
    const response = await fetch('/api/auth/me', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
    })
    if (response.ok) {
      const user = (await response.json()) as ServerUser
      // 关键隔离：按用户选择本地 IndexedDB，切换账号不会读取/上传前一个账号的缓存
      setChatDatabaseUser(user.id)
      useServerSession.setState({ user, checked: true })
      return
    }
    if (response.status === 401) {
      redirectToLogin()
      return
    }
  } catch {
    // 网络异常时保留当前界面，后续请求会再次触发 401 跳转
  }
  useServerSession.setState((state) => ({ ...state, checked: true }))
}
